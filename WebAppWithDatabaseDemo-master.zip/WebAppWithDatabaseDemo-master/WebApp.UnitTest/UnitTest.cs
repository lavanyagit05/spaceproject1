using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WebApp.UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void UnitTestShouldAlwaysWorkTest()
        {
            Assert.IsTrue(true);
        }

        [TestMethod]
        public void OnePlusTwoEqualThreeTest()
        {
            Assert.IsTrue(true);
        }
    }
}
